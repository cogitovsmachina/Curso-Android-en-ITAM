===================================================
Android Screenshots and Screen Capture 1.1
===================================================

Before you begin, please make sure you have installed:

   - JDK 
     http://www.oracle.com/technetwork/java/javase/downloads/index.html

   - Android SDK
     http://developer.android.com/sdk/index.html

Remark: it is enough to complete "Prepare your development computer"
        and "Download and install the SDK starter package" steps
        from Android SDK Quick Start.

   - (Windows Only): Install USB driver
     http://developer.android.com/sdk/win-usb.html

===================================================
Launching application
===================================================

To start taking screenshots of your Android phone launch the 
following file which can be found in the same folder as this
readme file:

   AShot-1.0.jar

and provide the path to Android SDK in File -> Android SDK path...

You are all set!

For more details please visit:

   http://www.mightypocket.com/2010/08/android-screenshots-screen-capture-screen-cast/
